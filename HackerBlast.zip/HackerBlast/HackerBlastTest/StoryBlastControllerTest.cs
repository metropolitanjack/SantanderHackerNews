using HackerBlast.Controllers;
using HackerBlast.Interfaces;
using HackerBlast.Services;
using Moq;

namespace HackerBlastTest
{
    public class Tests
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void GivenNonEmptyCacheShouldNotReloadCache()
        {
            bool reloadedCache = false;

            var mockApiClient = new Mock<IHackerNewsApiClient>();
            mockApiClient
                .Setup(x => x.GetBestStories()).Returns(new string[] { })
                .Callback(() => reloadedCache = true);

            var nonemptyCache = new HackerNewsCache(new string[] {"11111", "222222"});


            StoryBlastController sb = new(null!, nonemptyCache, mockApiClient.Object);
            sb.Get(6);
            Assert.False(reloadedCache);
        }

        [Test]
        public void GivenEmptyCacheShouldReloadCache()
        {
            bool reloadedCache = false;

            var mockApiClient = new Mock<IHackerNewsApiClient>();
            mockApiClient
                .Setup(x => x.GetBestStories()).Returns(Array.Empty<string>())
                .Callback(() => reloadedCache = true);

            var emptyCache = new HackerNewsCache();



            StoryBlastController sb = new(null!, emptyCache, mockApiClient.Object);
            sb.Get(6);
            Assert.True(reloadedCache);
        }

        [Test]
        public void GivenMultipleRequestsShouldNotBlockOnCache()
        {
            int concurrentRequestCount = 100;
            int reloadedCacheCount = 0;
            object sync = new object();

            var mockApiClient = new Mock<IHackerNewsApiClient>();
            mockApiClient
                .Setup(x => x.GetBestStories()).Returns(Array.Empty<string>())
                .Callback(() => { 
                    lock(sync) { reloadedCacheCount++; }
                     });

            var emptyCache = new HackerNewsCache();

            
            List<Thread> threads = new List<Thread>();
            for(int k = 0; k < concurrentRequestCount; k++)
            {
                StoryBlastController sb = new(null!, emptyCache, mockApiClient.Object);
                var t = new Thread(()=>sb.Get(6));
                t.Start();
                threads.Add(t);
            }
            foreach (var t in threads) 
                t.Join();

            Assert.That(reloadedCacheCount, Is.EqualTo(concurrentRequestCount));
        }
    }
}