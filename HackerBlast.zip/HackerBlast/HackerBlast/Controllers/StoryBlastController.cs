﻿using HackerBlast.Interfaces;
using HackerBlast.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Reflection;

namespace HackerBlast.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StoryBlastController : ControllerBase
    {

        private readonly ILogger<StoryBlastController> _logger;
        private readonly IHackerNewsCache _iHackerNewsCache;
        private readonly IHackerNewsApiClient _iHackerNewsApiClient;

        public StoryBlastController(ILogger<StoryBlastController> logger, IHackerNewsCache iHackerNewsCache, IHackerNewsApiClient iHackerNewsApiClient)
        {
            _logger = logger;
            _iHackerNewsApiClient = iHackerNewsApiClient;
            _iHackerNewsCache = iHackerNewsCache;
        }

        [HttpGet]
        public IEnumerable<IHackerNewsStory> Get(int n=5)
        {
            var stories = new List<IHackerNewsStory>();

            string[] bestStoryIds = _iHackerNewsCache.GetBestStoryIds(this.GetBestStoryIdsFromApi);

            if (bestStoryIds.Length < 1)
                return stories;

            var actualIds = bestStoryIds.Take(
                bestStoryIds.Length > n ? n : bestStoryIds.Length
                );

            
            foreach(var id in actualIds)
            {
                var storyDetail = _iHackerNewsApiClient.GetStoryDetail(id);
                stories.Add(storyDetail);
            }

            return stories;

        }

        private string[] GetBestStoryIdsFromApi()
        {
            return _iHackerNewsApiClient.GetBestStories();

        }
    }
}
