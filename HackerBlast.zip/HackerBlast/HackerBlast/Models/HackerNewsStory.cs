﻿using HackerBlast.Interfaces;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace HackerBlast.Models
{

    public class HackerNewsStory : IHackerNewsStory
    {
        [JsonProperty("title")]
        public string? title { get; set; }

        [JsonProperty("url")]
        public string? uri { get; set; }

        [JsonProperty("by")]
        public string? postedBy { get; set; }

        [JsonProperty("time")]
        [JsonConverter(typeof(UnixDateTimeConverter))]
        public DateTime? time { get; set; }

        [JsonProperty("score")]
        public int? score { get; set; }

        [JsonProperty("descendants")]
        public int? commentCount { get; set; }

    }
}
