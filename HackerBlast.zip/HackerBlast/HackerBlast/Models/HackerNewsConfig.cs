﻿namespace HackerBlast.Models
{
    public class HackerNewsConfig
    {
        public string? BestStoryIdsUrl {  get; set; }
        public string? StoryDetailsUrl {  get; set; }
    }
}
