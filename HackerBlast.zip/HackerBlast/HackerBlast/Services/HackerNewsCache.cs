﻿using HackerBlast.Interfaces;
using Microsoft.Extensions.ObjectPool;

namespace HackerBlast.Services
{
    public class HackerNewsCache : IHackerNewsCache
    {
        object _lock = new object();
        DateTime _lastRefresh;
        string[] _bestStoryIds;
        int _refreshIntervalMins = 5;


        public HackerNewsCache(string[]? bestStoryIds = null, int refreshIntervalMins = 5) {
            _refreshIntervalMins = refreshIntervalMins;
            if(bestStoryIds != null)
            {
                _bestStoryIds = bestStoryIds;
                _lastRefresh = DateTime.Now;
            }
            else _bestStoryIds = new string[] { };
        }

        public string[] GetBestStoryIds(Func<string[]> refreshFn)
        {
            lock (_lock)
            {
                if ((_bestStoryIds.Length == 0) || (DateTime.Now.Subtract(_lastRefresh).Minutes > _refreshIntervalMins))
                {
                    _bestStoryIds = refreshFn.Invoke();
                    _lastRefresh = DateTime.Now;
                }
                return _bestStoryIds;
            }
        }

    }
}
