﻿using HackerBlast.Interfaces;
using HackerBlast.Models;
using Newtonsoft.Json;
using System.Text.Json.Serialization;

namespace HackerBlast.Services
{
    public class HackerNewsApiClient : IHackerNewsApiClient
    {
        string _bestStoriesUrl;
        string _storyDetailsUrl;

        public HackerNewsApiClient(string bestStoriesUrl, string storyDetailsUrl) {
            _bestStoriesUrl = bestStoriesUrl;
            _storyDetailsUrl = storyDetailsUrl;

        }

        public string[] GetBestStories()
        {

            HttpClient httpClient = new HttpClient();
            HttpResponseMessage response = httpClient.GetAsync(_bestStoriesUrl).Result;
            response.EnsureSuccessStatusCode();
            var jsonString = response.Content.ReadAsStringAsync().Result;
            var ret = JsonConvert.DeserializeObject<string[]>(jsonString);
            return ret ?? Array.Empty<string>();
            
        }
        public IHackerNewsStory GetStoryDetail(string storyId)
        {
            HttpClient httpClient = new HttpClient();
            HttpResponseMessage response = httpClient.GetAsync(_storyDetailsUrl + storyId + ".json").Result;
            response.EnsureSuccessStatusCode();
            var jsonString = response.Content.ReadAsStringAsync().Result;
            var ret = JsonConvert.DeserializeObject<HackerNewsStory>(jsonString);
            return ret!;
            
        }
    }
}
