﻿namespace HackerBlast.Interfaces
{
    public interface IHackerNewsStory
    {
        string? title { get; set; }
        string? uri { get; set; }
        string? postedBy { get; set; }
        DateTime? time { get; set; }
        int? score { get; set; }
        int? commentCount { get; set; }

    }
}
