﻿namespace HackerBlast.Interfaces
{
    public interface IHackerNewsApiClient
    {
        string[] GetBestStories();
        IHackerNewsStory GetStoryDetail(string storyId);
    }
}
