﻿namespace HackerBlast.Interfaces
{
    public interface IHackerNewsCache
    {
        string[] GetBestStoryIds(Func<string[]> refreshFn);
    }
}
